#include "report.h"
#include "uart.h"

static char *put_str(char *p, const char *s)
{
    while (*s) *p++ = *s++;
    return p;
}

/* Unsigned fixed-point: val with 'decimals' implied decimal places. */
static char *put_fixed(char *p, uint32_t val, uint8_t decimals)
{
    char tmp[11];
    uint8_t n = 0;
    do {
        tmp[n++] = (char)('0' + val % 10);
        val /= 10;
    } while (val || n <= decimals);
    for (uint8_t k = n; k > 0; k--) {
        *p++ = tmp[k - 1];
        if (decimals && (k - 1) == decimals) *p++ = '.';
    }
    return p;
}

static uint32_t to_u32(float x) { return (x <= 0.0f) ? 0UL : (uint32_t)(x + 0.5f); }

void report_send(const meas_t *m, float energy_wh)
{
    char buf[72];
    char *p = buf;
    p = put_str(p, "V=");  p = put_fixed(p, to_u32(m->v_rms * 100.0f), 2);
    p = put_str(p, " Vrms, I="); p = put_fixed(p, to_u32(m->i_pk_mA), 0);
    p = put_str(p, " mApk, P="); p = put_fixed(p, to_u32(m->p_w * 100.0f), 2);
    p = put_str(p, " W, E=");    p = put_fixed(p, to_u32(energy_wh * 1000.0f), 3);
    p = put_str(p, " Wh\r\n");
    *p = '\0';
    uart_tx(buf);
}

void report_dump_samples(const uint16_t *v, const uint16_t *i, uint8_t n)
{
    char buf[16];
    for (uint8_t k = 0; k < n; k++) {
        char *p = buf;
        p = put_fixed(p, v[k], 0);
        p = put_str(p, ", ");
        p = put_fixed(p, i[k], 0);
        p = put_str(p, "\r\n");
        *p = '\0';
        uart_tx(buf);
    }
}
