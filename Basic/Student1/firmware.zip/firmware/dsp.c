#include "dsp.h"
#include <math.h>

float calc_rms(const uint16_t *x, uint8_t n)
{
    uint32_t sum = 0, sumsq = 0;
    for (uint8_t k = 0; k < n; k++) {
        uint32_t s = x[k];
        sum   += s;
        sumsq += s * s;
    }
    /* sum((x-mean)^2) = sumsq - sum^2/n, exact in integers */
    int64_t acc = (int64_t)sumsq - (int64_t)(((uint64_t)sum * sum) / n);
    return sqrtf((float)acc / n);
}

float calc_peak(float rms)
{
    /* Peak-detecting 8 samples/cycle would under-read by up to 7.6 %, so use RMS. */
    return rms * 1.41421356f;
}

float calc_power(const uint16_t *v, const uint16_t *i, uint8_t n)
{
    uint32_t sum_w = 0, sum_i = 0, sum_wi = 0;
    for (uint8_t k = 0; k < n; k++) {
        uint32_t w  = (uint32_t)v[k] + v[k + 1];   /* 2 x interpolated V at the I instant */
        uint32_t ik = i[k];
        sum_w  += w;
        sum_i  += ik;
        sum_wi += w * ik;
    }
    /* covariance(v_interp, i) = [sum_wi - sum_w*sum_i/n] / (2n)  -> removes both DC offsets */
    int64_t cov2 = (int64_t)sum_wi - (int64_t)(((uint64_t)sum_w * sum_i) / n);
    return (float)cov2 / (2.0f * n);
}
