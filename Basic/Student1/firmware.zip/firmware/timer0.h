#ifndef TIMER0_H_
#define TIMER0_H_
#include <stdint.h>

void timer0_init(void);        /* 1 ms tick; also steps the display every 2 ms */
uint32_t timer0_ms(void);      /* ms since init (atomic read) */

#endif
