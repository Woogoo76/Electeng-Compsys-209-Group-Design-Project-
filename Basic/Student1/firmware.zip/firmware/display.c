/* 4-digit multiplexed 7-seg driven through a 74HC595 (bit-banged).
 * Segment byte: bit7 = dp ... bit0 = a. Shifted MSB first (Lab 6).
 * Layout: [d][d][d][unit]   V: "14.1U"  I: "842A"  P: "6.16P"                */
#include "display.h"
#include "pins.h"
#include <avr/io.h>
#include <util/atomic.h>

#define DISP_DIGITS 4
#define SEG_DP      0x80
#define SEG_BLANK   0x00
#define SEG_U       0x3E
#define SEG_A       0x77
#define SEG_P       0x73
#define DP_NONE     0xFF

static const uint8_t seg_digit[10] = {
    0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F   /* Lab 6 QP.1 */
};

/* Front/back buffers: ISR reads front, main writes back, swap on a digit-cycle boundary. */
static volatile uint8_t s_buf[2][DISP_DIGITS];
static volatile uint8_t s_front;
static volatile uint8_t s_swap_req;
static uint8_t s_pos;

void display_init(void)
{
    PIN_OUTPUT(SH_CP); PIN_OUTPUT(SH_DS); PIN_OUTPUT(SH_ST);
    PIN_OUTPUT(DS1); PIN_OUTPUT(DS2); PIN_OUTPUT(DS3); PIN_OUTPUT(DS4);
    PIN_LOW(SH_CP); PIN_LOW(SH_ST);
    PIN_HIGH(DS1); PIN_HIGH(DS2); PIN_HIGH(DS3); PIN_HIGH(DS4);   /* all digits off */
}

static void digits_disable_all(void)
{
    PIN_HIGH(DS1); PIN_HIGH(DS2); PIN_HIGH(DS3); PIN_HIGH(DS4);
}

static void digit_enable(uint8_t pos)     /* pos 0 = leftmost = Ds1 (swap here if mirrored) */
{
    switch (pos) {
    case 0: PIN_LOW(DS1); break;
    case 1: PIN_LOW(DS2); break;
    case 2: PIN_LOW(DS3); break;
    default: PIN_LOW(DS4); break;
    }
}

static void shift_out_and_latch(uint8_t pattern)
{
    for (uint8_t bit = 0x80; bit; bit >>= 1) {
        if (pattern & bit) PIN_HIGH(SH_DS); else PIN_LOW(SH_DS);
        PIN_HIGH(SH_CP);
        PIN_LOW(SH_CP);
    }
    PIN_HIGH(SH_ST);
    PIN_LOW(SH_ST);
}

void display_isr_step(void)
{
    if (s_pos == 0 && s_swap_req) { s_front ^= 1; s_swap_req = 0; }

    digits_disable_all();                          /* no ghosting */
    shift_out_and_latch(s_buf[s_front][s_pos]);    /* segments first (Lab 6 Q1.2) ... */
    digit_enable(s_pos);                           /* ... then enable the digit */
    s_pos = (s_pos + 1) & (DISP_DIGITS - 1);
}

static void display_write(const uint8_t seg[DISP_DIGITS])
{
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
        uint8_t back = s_front ^ 1;
        for (uint8_t k = 0; k < DISP_DIGITS; k++) s_buf[back][k] = seg[k];
        s_swap_req = 1;
    }
}

/* val 0..999 -> 3 digits (+dp after digit dp_pos) + unit glyph. Leading zeros blanked. */
static void format_7seg(uint16_t val, uint8_t dp_pos, uint8_t unit, uint8_t out[DISP_DIGITS])
{
    uint8_t d[3] = { (uint8_t)(val / 100), (uint8_t)((val / 10) % 10), (uint8_t)(val % 10) };
    uint8_t limit = (dp_pos == DP_NONE) ? 2 : dp_pos;   /* never blank the digit at/after dp */
    uint8_t leading = 1;
    for (uint8_t p = 0; p < 3; p++) {
        if (leading && d[p] == 0 && p < limit) {
            out[p] = SEG_BLANK;
        } else {
            leading = 0;
            out[p] = seg_digit[d[p]];
        }
        if (p == dp_pos) out[p] |= SEG_DP;
    }
    out[3] = unit;
}

static uint16_t to_u16_clamped(float x)
{
    if (x < 0.0f) return 0;
    if (x > 999.0f) return 999;
    return (uint16_t)(x + 0.5f);
}

void display_show_quantity(disp_quantity_t q, float value)
{
    uint8_t f[DISP_DIGITS];
    switch (q) {
    case DISP_VOLT:    format_7seg(to_u16_clamped(value * 10.0f),  1,       SEG_U, f); break;
    case DISP_CURRENT: format_7seg(to_u16_clamped(value),          DP_NONE, SEG_A, f); break;
    default:           format_7seg(to_u16_clamped(value * 100.0f), 0,       SEG_P, f); break;
    }
    display_write(f);
}
