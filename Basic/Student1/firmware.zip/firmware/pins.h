#ifndef PINS_H_
#define PINS_H_
#include <avr/io.h>

/* Helper macros: a pin "X" needs X_PORT, X_DDR and X_BIT defined below. */
#define PIN_OUTPUT(p) ((p##_DDR)  |=  (1 << (p##_BIT)))
#define PIN_HIGH(p)   ((p##_PORT) |=  (1 << (p##_BIT)))
#define PIN_LOW(p)    ((p##_PORT) &= ~(1 << (p##_BIT)))
#define PIN_TOGGLE(p) ((p##_PIN)   =  (1 << (p##_BIT)))   /* writing 1 to PINx toggles */

/* ADC channels (Lab 4: ADC0 = voltage signal, ADC1 = current signal) */
#define ADC_CH_V 0
#define ADC_CH_I 1

/* Pin map taken from Overall_Project_Proteus.pdsprj */
/* 74HC595 shift register (Q0 = segment a ... Q7 = dp) */
#define SH_CP_PORT PORTC
#define SH_CP_DDR  DDRC
#define SH_CP_BIT  PC3
#define SH_DS_PORT PORTC
#define SH_DS_DDR  DDRC
#define SH_DS_BIT  PC4
#define SH_ST_PORT PORTC
#define SH_ST_DDR  DDRC
#define SH_ST_BIT  PC5

/* Digit enables (common cathodes, active LOW). Assumed Ds1 = leftmost digit. */
#define DS1_PORT PORTD
#define DS1_DDR  DDRD
#define DS1_BIT  PD4
#define DS2_PORT PORTD
#define DS2_DDR  DDRD
#define DS2_BIT  PD5
#define DS3_PORT PORTD
#define DS3_DDR  DDRD
#define DS3_BIT  PD6
#define DS4_PORT PORTD
#define DS4_DDR  DDRD
#define DS4_BIT  PD7

/* Debug (DEBUG_PINS=1): EoC toggles the LED pin PB5 (already on Proteus scope ch D).
 * SoC is the hardware OC1B pin PB2 - unconnected in the model; wire it to a scope channel. */
#define DBG_EOC_PORT PORTB
#define DBG_EOC_DDR  DDRB
#define DBG_EOC_PIN  PINB
#define DBG_EOC_BIT  PB5

#endif
