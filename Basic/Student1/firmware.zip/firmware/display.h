#ifndef DISPLAY_H_
#define DISPLAY_H_
#include <stdint.h>

typedef enum { DISP_VOLT = 0, DISP_CURRENT = 1, DISP_POWER = 2 } disp_quantity_t;

void display_init(void);
/* Format as 3 digits + unit letter (U, A, P) and queue it (double-buffered). */
void display_show_quantity(disp_quantity_t q, float value);
/* Called from the 2 ms timer tick: draws one digit (scan + shift register). */
void display_isr_step(void);

#endif
