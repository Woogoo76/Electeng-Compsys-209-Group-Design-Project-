#ifndef CALIB_H_
#define CALIB_H_
/* Analogue front-end constants (from Labs 1 & 3). Edit to match what you BUILT,
 * then fine-trim V_TRIM / I_TRIM against a multimeter. */

#define ADC_VREF_V    5.0f
#define ADC_STEPS     1024.0f

#define VDIV_RA_OHM   56000.0f     /* Lab 1 Q4.1 */
#define VDIV_RB_OHM   2700.0f
#define V_AMP_GAIN    1.0f         /* Lab 3 Q3.1 diff amp (R2/R1) */

#define RSHUNT_OHM    0.5f         /* Lab 1 Q3.1 */
#define I_AMP_GAIN    (68000.0f / 30000.0f)   /* Lab 3 Q2.1: R2/R1 */
#define I_SENSE_SIGN  1.0f         /* set -1.0f if power reads negative (sense polarity) */

#define V_TRIM        1.0f
#define I_TRIM        1.0f

/* Source volts / amps per ADC count (AC-coupled, so the 2.1 V offset drops out) */
#define VOLTS_PER_COUNT ((ADC_VREF_V / ADC_STEPS) * ((VDIV_RA_OHM + VDIV_RB_OHM) / VDIV_RB_OHM) / V_AMP_GAIN * V_TRIM)
#define AMPS_PER_COUNT  ((ADC_VREF_V / ADC_STEPS) / (I_AMP_GAIN * RSHUNT_OHM) * I_TRIM)

/* V and I are sampled 125 us apart (interleaved). Averaging two neighbouring V
 * samples to line up with I loses cos(2*pi*500Hz*125us) = cos(22.5deg) of amplitude. */
#define SAMPLE_SKEW_COS 0.92388f

#endif
