#include "timer0.h"
#include "display.h"
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/atomic.h>

#define DISPLAY_STEP_MS 2      /* 4 digits x 2 ms = 125 Hz refresh (> 30 Hz) */

static volatile uint32_t s_ms;
static uint8_t s_div;

void timer0_init(void)
{
    TCCR0A = (1 << WGM01);               /* CTC */
    OCR0A  = 249;                        /* 2 MHz / 8 = 250 kHz -> 250 counts = exactly 1 ms */
    TIMSK0 = (1 << OCIE0A);
    TCCR0B = (1 << CS01);                /* prescaler 8 */
}

uint32_t timer0_ms(void)
{
    uint32_t t;
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE) { t = s_ms; }
    return t;
}

/* ISR_NOBLOCK re-enables interrupts so the ADC ISR (tight timing) can preempt the
 * display bit-banging. Nothing else here can re-enter, the step takes << 1 ms. */
ISR(TIMER0_COMPA_vect, ISR_NOBLOCK)
{
    s_ms++;
    if (++s_div >= DISPLAY_STEP_MS) {
        s_div = 0;
        display_isr_step();
    }
}
