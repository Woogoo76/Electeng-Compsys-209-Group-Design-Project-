#ifndef COMMON_H_
#define COMMON_H_

#ifndef F_CPU
#define F_CPU 2000000UL          /* MCU system clock (design spec) */
#endif
#define UART_BAUD 9600UL         /* design spec */

/* ---- Build options ---- */
#define DEBUG_PINS            0  /* 1: SoC (OC1B) + EoC pin toggles for the test record */
#define DUMP_RAW_FIRST_WINDOW 1  /* 1: print first raw ADC window over UART (paste into Excel) */

#define SCROLL_MS      1000UL    /* display scroll period (spec: 1 s) */
#define UART_PERIOD_MS 1000UL    /* UART report period */

#endif
