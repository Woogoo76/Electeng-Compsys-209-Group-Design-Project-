/* ELECTENG209 energy monitor firmware
 *
 *  Timer1 --(125 us)--> ADC auto-trigger --> ADC ISR fills v[]/i[] and stops itself
 *  main(): INIT -> WAIT (flag) -> PROCESS -> REPORT -> REARM -> WAIT ...
 *  Timer0 (1 ms) --> time base + 7-seg scan (runs in parallel, double-buffered)
 */
#include "common.h"
#include "adc.h"
#include "timer0.h"
#include "display.h"
#include "uart.h"
#include "measure.h"
#include "report.h"
#include <avr/io.h>
#include <avr/interrupt.h>

typedef enum { ST_INIT, ST_WAIT, ST_PROCESS, ST_REPORT, ST_REARM } state_t;

static meas_t   g_meas;            /* smoothed result */
static float    g_energy_wh;
static uint32_t g_last_energy_ms;
static uint32_t g_last_uart_ms;
static uint8_t  g_have_data;

static void do_init(void)
{
    uart_init();
    display_init();
    adc_init();
    timer0_init();
    sei();
    g_last_energy_ms = timer0_ms();
}

static void do_process(void)
{
    meas_t m;

#if DUMP_RAW_FIRST_WINDOW
    if (!g_have_data) {
        report_dump_samples(adc_v_samples(), adc_i_samples(), ADC_N_PAIRS);
        g_last_energy_ms = timer0_ms();      /* don't count the dump time as energy */
    }
#endif

    measure_compute(adc_v_samples(), adc_i_samples(), ADC_N_PAIRS, &m);
    measure_filter(&g_meas, &m, !g_have_data);
    g_have_data = 1;

    uint32_t now = timer0_ms();              /* rectangle-rule energy integration */
    g_energy_wh += g_meas.p_w * (float)(now - g_last_energy_ms) / 3.6e6f;
    g_last_energy_ms = now;
}

static void do_report(void)
{
    uint32_t now = timer0_ms();

    /* scroll V -> I -> P, one per SCROLL_MS */
    disp_quantity_t q = (disp_quantity_t)((now / SCROLL_MS) % 3);
    float val = (q == DISP_VOLT) ? g_meas.v_rms
              : (q == DISP_CURRENT) ? g_meas.i_pk_mA
              : g_meas.p_w;
    display_show_quantity(q, val);

    if (now - g_last_uart_ms >= UART_PERIOD_MS) {
        report_send(&g_meas, g_energy_wh);
        g_last_uart_ms = now;
    }
}

int main(void)
{
    state_t state = ST_INIT;

    for (;;) {
        switch (state) {
        case ST_INIT:    do_init(); adc_start_window(); state = ST_WAIT;   break;
        case ST_WAIT:    if (adc_window_ready()) state = ST_PROCESS;       break;
        case ST_PROCESS: do_process();           state = ST_REPORT;        break;
        case ST_REPORT:  do_report();            state = ST_REARM;         break;
        case ST_REARM:   adc_start_window();     state = ST_WAIT;          break;
        }
    }
}
