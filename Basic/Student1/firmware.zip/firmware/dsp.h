#ifndef DSP_H_
#define DSP_H_
#include <stdint.h>

/* Pure functions: outputs depend only on inputs. All results are in ADC counts. */
float calc_rms(const uint16_t *x, uint8_t n);   /* AC-coupled RMS (mean removed) */
float calc_peak(float rms);                     /* sinusoid peak = sqrt(2) * rms */
/* Real power (count^2). v has n+1 samples, i has n; i[k] lies midway between v[k], v[k+1].
 * Not yet corrected for the interpolation loss (see SAMPLE_SKEW_COS). */
float calc_power(const uint16_t *v, const uint16_t *i, uint8_t n);

#endif
