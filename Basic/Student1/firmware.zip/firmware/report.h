#ifndef REPORT_H_
#define REPORT_H_
#include <stdint.h>
#include "measure.h"

/* "V=14.05 Vrms, I=495 mApk, P=6.16 W, E=0.123 Wh" over UART (no float printf needed) */
void report_send(const meas_t *m, float energy_wh);
/* "v, i" counts per line - copy/paste into Excel for the test record */
void report_dump_samples(const uint16_t *v, const uint16_t *i, uint8_t n);

#endif
