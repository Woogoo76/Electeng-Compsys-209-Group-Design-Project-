/* ADC acquisition: Timer1 (CTC, compare-match B) auto-triggers each conversion.
 * Samples alternate V, I, V, I ... V so every I sample sits between two V samples.
 * 125 kHz ADC clock (2 MHz / 16), 125 us trigger -> 8 kHz total (spec: <= 10 kHz). */
#include "adc.h"
#include "common.h"
#include "pins.h"
#include <avr/io.h>
#include <avr/interrupt.h>

#define ADMUX_V ((1 << REFS0) | ADC_CH_V)    /* AVcc reference */
#define ADMUX_I ((1 << REFS0) | ADC_CH_I)

static uint16_t g_v[ADC_N_PAIRS + 1];
static uint16_t g_i[ADC_N_PAIRS];
static volatile uint8_t s_ready;
static uint8_t s_k;        /* pair index */
static uint8_t s_phase;    /* 0 = next result is V, 1 = next result is I */

void adc_init(void)
{
    ADMUX  = ADMUX_V;
    ADCSRB = (1 << ADTS2) | (1 << ADTS0);          /* trigger: Timer1 compare match B */
    ADCSRA = (1 << ADEN) | (1 << ADPS2);           /* prescaler 16 -> 125 kHz */
    DIDR0  = (1 << ADC0D) | (1 << ADC1D);          /* digital input buffers off */

    /* Timer1: CTC, TOP = OCR1A, no prescaler (0.5 us/tick) */
    TCCR1A = 0;
#if DEBUG_PINS
    DDRB  |= (1 << PB2);                           /* OC1B */
    TCCR1A = (1 << COM1B0);                        /* toggle OC1B on match = SoC marker */
    PIN_OUTPUT(DBG_EOC);
#endif
    TCCR1B = (1 << WGM12) | (1 << CS10);
    OCR1A  = 249;                                  /* 250 ticks = 125 us */
    OCR1B  = 100;
    TIMSK1 = (1 << OCIE1B);                        /* needed so the flag is cleared (see ISR) */
}

void adc_start_window(void)
{
    s_k = 0;
    s_phase = 0;
    s_ready = 0;
    ADMUX = ADMUX_V;
    ADCSRA |= (1 << ADATE) | (1 << ADIE);
}

uint8_t adc_window_ready(void) { return s_ready; }
const uint16_t *adc_v_samples(void) { return g_v; }
const uint16_t *adc_i_samples(void) { return g_i; }

/* Empty, naked ISR: the ADC trigger flag (OCF1B) must be cleared by someone.
 * ISR_NAKED = just a reti, ~4 cycles. */
ISR(TIMER1_COMPB_vect, ISR_NAKED)
{
    __asm__ __volatile__("reti");
}

/* End of conversion: store, pick next channel. Stops itself after the last sample. */
ISR(ADC_vect)
{
    uint16_t r = ADC;
#if DEBUG_PINS
    PIN_TOGGLE(DBG_EOC);
#endif
    if (s_phase == 0) {
        g_v[s_k] = r;
        if (s_k >= ADC_N_PAIRS) {                  /* got V[N]: window complete */
            ADCSRA &= ~((1 << ADATE) | (1 << ADIE));
            s_ready = 1;
            return;
        }
        ADMUX = ADMUX_I;
        s_phase = 1;
    } else {
        g_i[s_k++] = r;
        ADMUX = ADMUX_V;
        s_phase = 0;
    }
}
