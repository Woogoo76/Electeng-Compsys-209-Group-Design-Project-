#ifndef UART_H_
#define UART_H_
void uart_init(void);              /* 9600 8N1, TX only */
void uart_tx_char(char c);
void uart_tx(const char *s);       /* blocking, NUL-terminated */
#endif
