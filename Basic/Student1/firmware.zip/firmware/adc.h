#ifndef ADC_H_
#define ADC_H_
#include <stdint.h>

#define ADC_N_PAIRS 80   /* V/I pairs per window = 20 ms = exactly 10 cycles of 500 Hz */

void adc_init(void);                    /* ADC + Timer1 auto-trigger (125 us) */
void adc_start_window(void);            /* (re-)arm: collect one window, then stop */
uint8_t adc_window_ready(void);         /* 1 when a full window is in the buffers */
const uint16_t *adc_v_samples(void);    /* ADC_N_PAIRS + 1 samples */
const uint16_t *adc_i_samples(void);    /* ADC_N_PAIRS samples     */

#endif
