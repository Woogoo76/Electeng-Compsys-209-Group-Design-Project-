#include "uart.h"
#include "common.h"
#include <avr/io.h>

void uart_init(void)
{
    uint16_t ubrr = (uint16_t)(F_CPU / (16UL * UART_BAUD)) - 1;   /* = 12 (Lab 2 Q2.2) */
    UBRR0H = (uint8_t)(ubrr >> 8);
    UBRR0L = (uint8_t)ubrr;
    UCSR0A = 0;
    UCSR0B = (1 << TXEN0);                           /* transmitter only */
    UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);          /* 8 data bits, no parity, 1 stop */
}

void uart_tx_char(char c)
{
    while (!(UCSR0A & (1 << UDRE0))) { }
    UDR0 = c;
}

void uart_tx(const char *s)
{
    while (*s) uart_tx_char(*s++);
}
