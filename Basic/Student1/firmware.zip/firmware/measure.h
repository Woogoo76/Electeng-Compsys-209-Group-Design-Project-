#ifndef MEASURE_H_
#define MEASURE_H_
#include <stdint.h>

typedef struct {
    float v_rms;     /* V   */
    float i_pk_mA;   /* mA  */
    float p_w;       /* W   */
} meas_t;

/* Window of raw ADC counts -> engineering units. v: n+1 samples, i: n samples. */
void measure_compute(const uint16_t *v, const uint16_t *i, uint8_t n, meas_t *out);
/* Light IIR smoothing so the last display digit doesn't flicker. first=1 seeds it. */
void measure_filter(meas_t *acc, const meas_t *in, uint8_t first);

#endif
