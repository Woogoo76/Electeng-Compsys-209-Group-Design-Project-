#include "measure.h"
#include "dsp.h"
#include "calib.h"

void measure_compute(const uint16_t *v, const uint16_t *i, uint8_t n, meas_t *out)
{
    float v_rms = calc_rms(v, n) * VOLTS_PER_COUNT;
    float i_rms = calc_rms(i, n) * AMPS_PER_COUNT;
    float p = calc_power(v, i, n) * VOLTS_PER_COUNT * AMPS_PER_COUNT
              / SAMPLE_SKEW_COS * I_SENSE_SIGN;
    if (p < 0.0f) p = 0.0f;

    out->v_rms   = v_rms;
    out->i_pk_mA = calc_peak(i_rms) * 1000.0f;
    out->p_w     = p;
}

void measure_filter(meas_t *acc, const meas_t *in, uint8_t first)
{
    if (first) { *acc = *in; return; }
    acc->v_rms   += (in->v_rms   - acc->v_rms)   * 0.25f;
    acc->i_pk_mA += (in->i_pk_mA - acc->i_pk_mA) * 0.25f;
    acc->p_w     += (in->p_w     - acc->p_w)     * 0.25f;
}
